import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import env from '../env.json';

function Note() {
    let { noteURL } = useParams();
    const [noteText, setNoteText] = useState("");
    const [lineClass, setLineClass] = useState('hide');
    const [formClass, setFormClass] = useState('');
    const [errorClass, setErrorClass] = useState('hide');
    const [alertClass, setAlertClass] = useState('hide');

    useEffect(() => {
        if (noteURL !== undefined) {
            fetch(env.urlBackend, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: JSON.stringify({ "url": noteURL })
            })
                .then(response => response.json())
                .then(response => {
                    console.log(response);
                    if (response.result) {
                        console.log(response.note);
                        setNoteText(response.note);
                        setLineClass('');
                        setFormClass('hide');
                        setErrorClass('hide');
                    } else if (!response.result) {
                        setLineClass('hide');
                        setFormClass('hide');
                        setErrorClass('');
                    }
                })
        } else {
            setLineClass('hide');
            setFormClass('');
            setErrorClass('hide');
        }
    }, []);

    function getNote(event) {
        event.preventDefault();
        let url = event.target.elements.url.value;
        url = url.trim();
        if (url === '') {
            {/*} alert('Заполните поля');*/ }
            setAlertClass('');
            return false;
        }
        setAlertClass('hide');
        noteURL = url;
        window.location.href = env.url + '/' + url;
    }

    function searchNote() {
        window.location.href = env.url;
    }

    return (
        <div className="container d-flex flex-column align-items-center">
            <div className={lineClass}>
                <div>
                    <h2>Note:</h2>
                </div>
                <div className='noteText'>
                    <p class="card-subtitle mb-2 text-muted">{noteText}</p>
                </div>
                <div>
                    <button type='button' class="btn btn-secondary" onClick={searchNote}>Смотреть еще один Note</button>
                </div>
            </div>
            <div className={errorClass}>
                <div class="alert alert-warning alert-dismissible fade show alert-danger" role="alert">
                    <p><strong>Произошла ошибка! Попробуйте еще раз</strong></p>
                </div>
            </div>
            <div className={formClass}>
                <form onSubmit={getNote}>
                    <div className="d-flex flex-column">
                        <div className="mb-3">
                            <label htmlFor='url' className="form-label">Введите hash заметку:</label>
                            <input type='text' name='url' id='url' className='form-control' />
                        </div>
                        <button type="submit" class="btn btn-secondary">Искать Note</button>
                    </div>
                </form>
            </div>
            <div className={alertClass}>
                <div class="alert alert-warning alert-dismissible fade show alert-danger" role="alert">
                    <p><strong>Заполните полe!</strong></p>
                    <button type="button" class="btn-close btn-lg" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            </div>
        </div >
    );
}

export default Note;
