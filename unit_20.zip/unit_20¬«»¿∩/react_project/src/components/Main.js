function Main() {
    return (
        <main className="container">
            <section className="d-grid gap-2 col-6 mx-auto">
                <a href="/create" className="btn btn-secondary btn-lg" tabindex="-1" role="button" aria-disabled="true">Создать note</a>
                <a href="/note" className="btn btn-secondary btn-lg" tabindex="-1" role="button" aria-disabled="true">Просмотреть note</a>
            </section>
            <section className="text">
                <p><b>ShareNotes</b> – сервис для обмена заметками. Создайте заметку, отправьте ссылку на заметку и ваш друг сможет ее просмотреть.</p>
                <p><i>Как сделать заметку?</i></p>
                <ul>
                    <li>пройдите по ссылке;</li>
                    <li>вставьте текст и нажмите "Создать";</li>
                    <li>отправьте сгенерированный адрес другу.</li>
                </ul>
                <p><i>Как прочитать заметку?</i></p>
                <p>Перейдите по присланному URL, либо введите адрес руками здесь.</p>
            </section>
        </main >
    );
}

export default Main;