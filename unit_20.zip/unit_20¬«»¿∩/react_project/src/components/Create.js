import React from "react";
import { useState } from "react";
import env from '../env.json';

function Create() {
    const [url, setURL] = useState('');
    const [lineClass, setLineClass] = useState('hide');
    const [formClass, setFormClass] = useState('');
    const [alertClass, setAlertClass] = useState('hide');

    const sendData = (obj) => {
        setFormClass('hide');
        setLineClass('');
        {/*fetch("http://localhost:3500", {*/ }
        fetch(env.urlBackend, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: JSON.stringify(obj),
        })
            .then(response => response.json())
            .then(response => {
                console.log(response);
                if (response.result) {
                    setURL(env.url + '/' + response.url);
                }
            });
    }

    const loadDataFromForm = (event) => {
        event.preventDefault();
        let note = event.target.elements.note.value;
        note = note.trim();
        if (note === '') {
            {/*alert('Заполните поля');*/ }
            setAlertClass('');
            return false;
        }
        sendData({ "note": note });
        setAlertClass('hide');
    }

    return (
        <div className="container d-flex flex-column align-items-center">
            <form onSubmit={loadDataFromForm} className={formClass}>
                <div className="d-flex flex-column">
                    <div className="mb-3">
                        <label htmlFor="note" className="form-label">Введите заметку:</label>
                        <textarea className="form-control" id="note" defaultValue="Test" rows="3" />
                    </div>
                    <button type="submit" class="btn btn-secondary">Создать</button>
                </div>
            </form >
            <div className={alertClass}>
                <div class="alert alert-warning alert-dismissible fade show alert-danger" role="alert">
                    <p><strong>Заполните полe!</strong></p>
                    <button type="button" class="btn-close btn-lg" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            </div>
            <div className={lineClass}>
                <div className="alert alert-primary" role="alert">{url}</div>
                <p>Скопируйте URL и передайте адресату</p>
                <div>
                    <button type='button' class="btn btn-secondary" onClick={() => window.location.reload()}>Создать еще одну заметку</button>
                </div>
            </div>
        </div >
    );
}

export default Create;
