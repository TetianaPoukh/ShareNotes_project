import { NavLink } from 'react-router-dom';

function Header() {
    return (
        <header className="container">
            <div class="container-fluid row justify-content-between">
                <div class="col-5 mt-5 mx-3">
                    <a className="navbar-brand font-weight-bold link-secondary" href="/">
                        <h1>ShareNotes</h1>
                    </a>
                </div>
                <div class="container-fluid menu col-6 mt-5">
                    <nav class="navbar navbar-expand-lg navbar-light float-end">
                        <div class="container-fluid">
                            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup"
                                aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                            </button>
                            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                                <div class="navbar-nav">
                                    <ul className="navbar-nav mr-5">
                                        <li className="nav-item active">
                                            <NavLink exact className="nav-link" to="/">Home</NavLink>
                                        </li>
                                        <li class="nav-item">
                                            <NavLink className='nav-link' to="/note">Note</NavLink>
                                        </li>
                                        <li class="nav-item">
                                            <NavLink className='nav-link' to="/create">Create</NavLink>
                                        </li>
                                        <li class="nav-item">
                                            <NavLink className='nav-link' to="/about">About</NavLink>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
        </header >
    );
}

export default Header;
