function Footer() {
    return (
        <>
            <footer className="page-footer text-muted text-center border-0">
                <div className="container">
                    <p>&copy;2022 курс Reactjs</p>
                </div>
            </footer>
        </>
    );
}

export default Footer;
